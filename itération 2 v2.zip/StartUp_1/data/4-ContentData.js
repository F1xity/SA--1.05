let ContentData = {
    title: "Powerful Features",
    texte: "Everything you need to launch and grow yout buisness",
    cards: [
        {
            img: "asset-7",
            num: "01",
            name: "Fast Performance",
            texte: "Optimized for speed to deliver a lightning-fast user experience."
        },
        {
            img: "asset-8",
            num: "02",
            name: "Easy Customization",
            texte: "Edit and deploy your website without touching a single line of code."
        },
        {
            img: "asset-9",
            num: "03",
            name: "Fully Responsive",
            texte: "Your site looks great on desktops, tablets, and mobile devices."
        },
        {
            img: "asset-10",
            num: "04",
            name: "Secure by Design",
            texte: "Built with best practices to ensure maximum security and privacy."
        },
        {
            img: "asset-11",
            num: "05",
            name: "SEO Optimized",
            texte: "Stuctured and clean code that helps you rank higher on search engines effortlessly."
        },
        {
            img: "asset-12",
            num: "06",
            name: "Free Updates",
            texte: "Get future improvements and features at no extra cost-ensuring your site stays modern."
        }
    ]
};

export { ContentData };