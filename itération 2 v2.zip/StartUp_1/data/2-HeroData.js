let HeroData = [
    {
        title: "Supercharge Your Startup Launch",
        texte: "Launchly is a sleek, responsive landing page template built to convert visitors into customers - fast and efficiently.",
        btn:[
            {
                link: "sub",
                num: "1",
                name: "Get Started"
            },
            {
                link: "features",
                num: "2",
                name: "Learn More"
            }
        ]
    }
];

export {HeroData};