# SAé1.05 — Phase 2 : Intégration par composants

## 🎯 Objectifs

Cette phase consiste à **intégrer une maquette complète** en HTML/CSS en adoptant une approche par composants et mobile-first.

### Ce que vous devez faire :

1. **Analyser la maquette** fournie et identifier les différents composants (Header, Navigation, Hero, Cards, Footer, etc.)

2. **Créer chaque composant** en suivant la méthodologie établie dans la Phase 1 :

   - Créer un dossier dédié dans `/component/NomDuComposant/`
   - Rédiger le fichier `style.css` spécifique au composant
   - Importer le CSS dans `/css/global.css` via `@import "../component/NomDuComposant/style.css" layer(components);`
   - Ajouter le HTML du composant dans `index.html`

3. **Personnaliser les composants** grâce aux variables CSS personnalisées (ex: `--bg-hero`, `--bg-nav`, `--fg-nav`)

4. **Assembler la page complète** dans `index.html` en intégrant tous les composants créés.

### Remarques importantes :

- Les composants sont **statiques** pour l'instant (pas de JavaScript)
- Vous pouvez créer des **composants imbriqués** (ex: le Hero peut contenir la Navigation)
- Utilisez les **variables CSS** pour rendre vos composants personnalisables
- Adoptez une approche **mobile-first** en utilisant des media queries pour les adaptations desktop
- Respectez la **structure de fichiers** indiquée ci-dessous
- Suivez la **méthodologie BEM** pour nommer vos classes CSS
- Votre code doit être **propre, structuré, valide et commenté**

---

## 📁 Rappel : Structure du projet

```
SAé105_25-main/
├── index.html              # Page principale (intégration des composants)
├── css/
│   ├── global.css          # Imports et gestion des @layer
│   ├── variables.css       # Variables CSS globales
│   ├── reset.css           # Reset CSS
│   ├── base.css            # Styles de base
│   └── utilities.css       # Classes utilitaires (optionnel)
├── component/
│   ├── Hero/
│   │   └── style.css       # Styles du composant Hero
│   └── Navigation/
│       └── style.css       # Styles du composant Navigation
└── assets/
    └── hero-bg.jpg         # Ressources images
```

---

## 🎨 Design System

### Palette de couleurs

| Catégorie           | Couleurs                                                              |
| ------------------- | --------------------------------------------------------------------- |
| **Sombres**         | `#000000` `#0B0D17` `#111111` `#333333` `#444444` `#555555` `#666666` |
| **Gris**            | `#999999` `#AAAAAA` `#CCCCCC` `#E0E0E0` `#E2E8F0`                     |
| **Clairs**          | `#F1F5F9` `#F9F9F9` `#FDFDFD` `#FFFFFF`                               |
| **Accent (Teal)**   | `#009688` `#00BFA6` `#E0FCF1`                                         |
| **Accent (Orange)** | `#FF9800` `#FFC107`                                                   |

### Typographie

| Propriété           | Valeur                  |
| ------------------- | ----------------------- |
| **Font principale** | `'Poppins', sans-serif` |

### Assets

Vous devez **impérativement utiliser** les ressources graphiques disponibles dans le dossier `/assets/`

---

## ✅ Livrables attendus

- [ ] Tous les composants identifiés sont intégrés dans `/component/`
- [ ] Le fichier `index.html` affiche la maquette complète

commenté et respecte la méthodologie BEM et mobile-first
