let AvisData = {
    title: "What Our Users Say",
    avis: [
        {
            img: "asset-19",
            texte: "An excellent template overall. Clean code and a very polished mobile design.",
            person: "Daniel K., Design Lead"
        },
        {
            img: "asset-20",
            texte: "One of the best templates I’ve worked with. Clean code and excellent mobile layout.",
            person: "Alex T., Product Designer"
        },
        {
            img: "asset-21",
            texte: "Launchly gave our brand a strong online presence. Everything feels clean and professional.",
            person: "Emma W., Marketing Manager"
        },
        {
            img: "asset-24",
            texte: "It's one of the best templates I've used. Clear code and great mobile design.",
            person: "Thomas L., Creative Director"
        },
        {
            img: "asset-23",
            texte: "As a freelancer, having a strong online presence is everythings. Launchly nails it.",
            person: "Maya P., UX Designer"
        },
        {
            img: "asset-22",
            texte: "Launchly helped me launch my portfolio in days - it's fast, clean, and beautifully designed.",
            person: "Alex J., Web Developer"
        },
    ],
    num: [
        "none",
        "none",
        "none",
        "actif",
        "none",
        "none",
    ]
};

export { AvisData };