let ClientData = {
    title: "Our clients",
    subtitle: "TRUSTED BY TOP COMPANIES",
    imgs:[
        {img: "asset-1"},
        {img: "asset-2"},
        {img: "asset-3"},
        {img: "asset-4"},
        {img: "asset-5"},
        {img: "asset-6"},
    ]
}

export { ClientData }