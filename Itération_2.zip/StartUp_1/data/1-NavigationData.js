let NavigationData = {
    title: "Launchly",
    list:[
        {item : "Home", link : "#nav" },
        {item : "Features", link : "#content"},
        {item : "Pricing", link : "#sub"},
        {item : "Blog", link : "#blog"},
        {item : "Contact", link : "#help"}
    ],
}
export { NavigationData };