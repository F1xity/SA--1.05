let HeroData = [
    {
        title: "Supercharge Your Startup Launch",
        texte: "Launchly is a sleek, responsive landing page template built to convert visitors into customers - fast and efficiently.",
        img: "asset-0",
        btn:[
            {
                link: "#sub",
                num: "1",
                name: "Get Started"
            },
            {
                link: "#content",
                num: "2",
                name: "Learn More"
            }
        ]
    }
];

export {HeroData};