let FaqData = {
    title: "Frequently Asked Questions",
    texte: "Got quiestions? We've got answers.",
    questions: [
        {title: "Can I use this template for commercial projects?"},
        {title: "Do I need coding skills to use this template?"},
        {title: "Is support included with the template?"},
        {title: "Can I customize the layout and colors?"},
    ]
}

export { FaqData }