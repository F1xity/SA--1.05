let BioData ={
    titleBefore: "Bringing you the",
    titleHighlight: "best",
    titleAfter: "audio gear",
    description: "Located at the heart of New York City, Audiophile is the premier store for high end headphones, earphones, speakers, and audio accessories...",
    image: "./audiophile/assets/audiophile/man.jpeg",
    imageAlt: "Best audio gear"
}

export {BioData}