let BuyData = {
    items: [
        {
            img: "./audiophile/assets/audiophile/product_headphone.png",
            title: "HEADPHONES",
            link: "#buy",
            btn: "SHOP",
            arrow: "./audiophile/assets/audiophile/icones/fleche.svg"
        },
        {   
            img: "./audiophile/assets/audiophile/product_speak.png",
            title: "SPEAKERS",
            link: "#buy",
            btn: "SHOP",
            arrow: "./audiophile/assets/audiophile/icones/fleche.svg"
        },

        {
            img: "./audiophile/assets/audiophile/product_earphone.png",
            title: "EARPHONES",
            link: "#buy",
            btn: "SHOP",
            arrow: "./audiophile/assets/audiophile/icones/fleche.svg"
        },
    ],
}

export {BuyData}