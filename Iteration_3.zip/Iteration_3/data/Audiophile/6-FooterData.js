let FooterData = {
    logo: "./audiophile/assets/audiophile/logo.svg",
    description: "Audiophile is an all in one stop to fulfill your audio needs...",
    copyright: "Copyright 2021. All Rights Reserved",

    nav: [
        { name: "Home", link: "#" },
        { name: "Headphones", link: "#" },
        { name: "Speakers", link: "#" },
        { name: "Earphones", link: "#" }
    ],

    socials: [
        {
            name: "Facebook",
            link: "#",
            icon: "./audiophile/assets/audiophile/icones/facebook.svg"
        },
        {
            name: "Twitter",
            link: "#",
            icon: "./audiophile/assets/audiophile/icones/twitter.svg"
        },
        {
            name: "Instagram",
            link: "#",
            icon: "./audiophile/assets/audiophile/icones/insta.svg"
        }
    ]
}

export {FooterData}