let PreviewData ={
    img: "./audiophile/assets/audiophile/image-hero_mobile.jpg",
    new: "NEW PRODUCT",
    name: "XX99 Mark II Headphones",
    texte: "Experience natural, lifelike audio and exeptional build quality made for the passionate music enthusiast.",
    link: "#buy",
    btn: "SEE PRODUCT"
}

export {PreviewData}