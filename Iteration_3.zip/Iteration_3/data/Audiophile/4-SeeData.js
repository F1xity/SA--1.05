let SeeData = {
    items: [
        {
            bg: "./audiophile/assests/audiophile/icones/circle-pattern.svg",
            img: "./audiophile/assets/audiophile/product_speak.png",
            title: "ZX9 SPEAKER",
            texte: "Upgrade to premium speakers that are phenomenally built to deliver truly remarkable sound.",
            link: "#buy",
            btn: "SEE PRODUCT",
        },
        {   
            bg: "./audiophile/assests/audiophile/image-speaker_mobile.jpg",
            img: "",
            title: "ZX7 SPEAKER",
            texte: "",
            link: "#buy",
            btn: "SEE PRODUCT",
        },

        {
            bg: "./audiophile/assets/audiophile/image-hero_mobile.jpg",
            img: "",
            title: "",
            texte: "",
            link: "#buy",
            btn: "",
        },

        {
            bg: "",
            img: "",
            title: "YX1 EARPHONES",
            texte: "",
            link: "#buy",
            btn: "See Product",
        },
    ],
}

export {SeeData}