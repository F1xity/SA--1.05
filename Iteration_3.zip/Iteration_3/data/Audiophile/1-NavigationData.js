let NavigationData = {
    img: "./audiophile/assets/audiophile/logo.svg",
    burger: "./audiophile/assets/audiophile/icones/burger.svg",
    shop: "./audiophile/assets/audiophile/icones/shop.svg",
    navItem: [
        {link: "#nav", name: "Home"},
        {link: "#buy", name: "Headphones"},
        {link: "#buy", name: "Earphones"},
        {link: "#buy", name: "Speakers"},
    ]
}

export {NavigationData}