let FooterData = {
    
}

export {FooterData}