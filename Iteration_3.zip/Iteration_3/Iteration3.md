# SAé1.05 — Itération 3 : Intégration par composants

Cette Itération consiste à **intégrer une maquette audiophile complète** en HTML/CSS en adoptant une approche par **composants dynamiques** et **mobile-first**.

## Ce que vous devez faire :

1. **Analyser la maquette** fournie et identifier les différents composants (Header, Navigation, Hero, Cards, Footer, etc.)

2. **Créer chaque composant** en suivant les méthodologies utilisées:

   - **Personnaliser les composants** grâce aux variables personnalisées et aux classes CSS (Modifier : le M de BEM)
   - **Dynamiser les composants** à partir de jeux de données (cf. https://github.com/frederic-mora/Starter_SAe105_26_dyn ) :

3. **Assembler la page complète** dans `index.html` en intégrant tous les composants créés.

### DS Audiophile :

- #000000
- #CFCFCF
- #D87D4A
- #F1F1F1
- #FFFFFF

## Variants et Jeux de données

Ajuster vos données et vos styles CSS pour créer à partir des mêmes composants, une variante du site donnée : **audiophile** devient **BonBonbon**.

### DS BonBonbon :

- #000000
- #DB4D9A
- #E6D5D5
- #FFF9F0
- #FFFFFF
