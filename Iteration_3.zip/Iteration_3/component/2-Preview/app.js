const templateFile = await fetch("./component/2-Preview/Template/TemplatePreview.html");
const template = await templateFile.text();

let Preview = {};

Preview.format = function(data, css=""){
    let html = template;

    html = html.replaceAll("{{img}}", data.img);
    html = html.replaceAll("{{new}}", data.new);
    html = html.replaceAll("{{name}}", data.name);
    html = html.replaceAll("{{texte}}", data.texte);
    html = html.replaceAll("{{link}}", data.link);
    html = html.replaceAll("{{btn}}", data.btn);
    return html;
}

Preview.render = function(where, data, css=""){
    let node = document.querySelector(where);
    node.innerHTML += Preview.format(data, css);
}

export { Preview };
