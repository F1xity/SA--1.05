const templateFile = await fetch("./component/4-See/Template/TemplateSee.html");
const template = await templateFile.text();

let See = {};

See.format = function(data, css=""){
    let html = "";
    for(let item of data){
        let block = template;
        block = block.replaceAll("{{bg}}", item.bg);
        block = block.replaceAll("{{img}}", item.img);
        block = block.replaceAll("{{title}}", item.title);
        block = block.replaceAll("{{texte}}", item.texte);
        block = block.replaceAll("{{link}}", item.link);
        block = block.replaceAll("{{btn}}", item.btn);
        html += block;
    }
    return html;
}

See.render = function(where, data, css=""){
    let node = document.querySelector(where);
    node.innerHTML += See.format(data, css);
}

export { See };
